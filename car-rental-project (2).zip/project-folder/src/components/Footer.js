import React from 'react';

function Footer() {
  return <footer>© 2024 Car Rental</footer>;
}

export default Footer;